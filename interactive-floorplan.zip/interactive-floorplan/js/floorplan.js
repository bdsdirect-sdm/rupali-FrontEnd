// SVG Floor Plan Data
const svgData = `
<svg width="600" height="900" xmlns="http://www.w3.org/2000/svg">
    <!-- Main floor areas -->
    <rect x="50" y="60" width="220" height="350" fill="#c8e6c9" stroke="#000" stroke-width="1"/>
    <rect x="50" y="380" width="300" height="200" fill="#bbdefb" stroke="#000" stroke-width="1"/>
    <rect x="400" y="380" width="150" height="200" fill="#ffcdd2" stroke="#000" stroke-width="1"/>
    <rect x="300" y="600" width="200" height="250" fill="#e1bee7" stroke="#000" stroke-width="1"/>
    
    <!-- Rooms and features -->
    <rect x="70" y="80" width="180" height="180" fill="#a5d6a7" stroke="#000" stroke-width="1"/>
    <text x="160" y="170" text-anchor="middle" font-size="12">Research Collection</text>
    
    <rect x="70" y="280" width="80" height="100" fill="#a5d6a7" stroke="#000" stroke-width="1"/>
    <text x="110" y="330" text-anchor="middle" font-size="10">Study Room</text>
    
    <rect x="170" y="280" width="80" height="100" fill="#a5d6a7" stroke="#000" stroke-width="1"/>
    <text x="210" y="330" text-anchor="middle" font-size="10">Study Room</text>
    
    <rect x="100" y="400" width="200" height="160" fill="#90caf9" stroke="#000" stroke-width="1"/>
    <text x="200" y="480" text-anchor="middle" font-size="14">Collaborative Study Area</text>
    
    <rect x="420" y="400" width="100" height="80" fill="#ef9a9a" stroke="#000" stroke-width="1"/>
    <text x="470" y="440" text-anchor="middle" font-size="10">Office</text>
    
    <rect x="420" y="500" width="100" height="60" fill="#ef9a9a" stroke="#000" stroke-width="1"/>
    <text x="470" y="530" text-anchor="middle" font-size="10">Office</text>
    
    <rect x="320" y="620" width="160" height="100" fill="#d1c4e9" stroke="#000" stroke-width="1"/>
    <text x="400" y="670" text-anchor="middle" font-size="12">Computer Lab</text>
    
    <rect x="320" y="740" width="160" height="80" fill="#d1c4e9" stroke="#000" stroke-width="1"/>
    <text x="400" y="780" text-anchor="middle" font-size="12">Meeting Room</text>
    
    <!-- Key Points -->
    <circle cx="110" cy="456" r="8" fill="#ff0000" stroke="#000"/>
    <text x="110" y="440" text-anchor="middle" font-size="12">A</text>
    
    <circle cx="124" cy="390" r="8" fill="#ff0000" stroke="#000"/>
    <text x="124" y="374" text-anchor="middle" font-size="12">B</text>
    
    <circle cx="62" cy="73" r="8" fill="#ff0000" stroke="#000"/>
    <text x="62" y="57" text-anchor="middle" font-size="12">C</text>
    
    <circle cx="258" cy="73" r="8" fill="#ff0000" stroke="#000"/>
    <text x="258" y="57" text-anchor="middle" font-size="12">D</text>
    
    <circle cx="280" cy="410" r="8" fill="#ff0000" stroke="#000"/>
    <text x="280" y="394" text-anchor="middle" font-size="12">E</text>
    
    <circle cx="493" cy="561" r="8" fill="#ff0000" stroke="#000"/>
    <text x="493" y="545" text-anchor="middle" font-size="12">F</text>
    
    <circle cx="295" cy="828" r="8" fill="#ff0000" stroke="#000"/>
    <text x="295" y="812" text-anchor="middle" font-size="12">G</text>
    
    <circle cx="283" cy="868" r="8" fill="#ff0000" stroke="#000"/>
    <text x="283" y="852" text-anchor="middle" font-size="12">H</text>
    
    <!-- Stairs and Elevators -->
    <rect x="40" y="350" width="20" height="20" fill="#ffd54f" stroke="#000"/>
    <text x="50" y="365" text-anchor="middle" font-size="14">S</text>
    
    <rect x="370" y="350" width="20" height="20" fill="#ffc107" stroke="#000"/>
    <text x="380" y="365" text-anchor="middle" font-size="14">E</text>
    
    <rect x="370" y="600" width="20" height="20" fill="#ffc107" stroke="#000"/>
    <text x="380" y="615" text-anchor="middle" font-size="14">E</text>
    
    <rect x="40" y="600" width="20" height="20" fill="#ffd54f" stroke="#000"/>
    <text x="50" y="615" text-anchor="middle" font-size="14">S</text>
</svg>
`;

// Define key points on the map
const points = {
    'A': [110.6189462165178, 456.64349563895087],
    'B': [123.9272226116071, 389.9520693708147],
    'C': [61.58708083147317, 72.8954315876116],
    'D': [258.29514854771196, 72.8954315876116],
    'E': [280.5277985253906, 410.2406672084263],
    'F': [492.8750778390066, 560.9895157073103],
    'G': [294.9255269587053, 827.9639780566406],
    'H': [282.79803391043527, 868.2476088113839],
    'Entrance': [110.6189462165178, 456.64349563895087],
    'Classroom': [260.75457021484374, 336.8559607533482],
    'Study Room': [221.36468155133926, 758.7870354617745],
    'Cafeteria': [366.8489324762834, 560.9895157073103]
};

// Set up predefined routes with waypoints
const presetRoutes = {
    'A-B': [points['A'], points['B']],
    'C-E': [points['C'], points['D'], points['E']],
    'B-D': [points['B'], points['A'], points['Entrance'], points['Classroom'], points['D']],
    'D-F': [points['D'], points['E'], points['F']],
    'A-F': [points['A'], points['E'], points['F']]
};

// Path finding algorithm (simplified for this example)
function findPath(start, end) {
    // In a real application, you would use a proper pathfinding algorithm
    // For this example, we're using direct paths between points
    return [points[start], points[end]];
}