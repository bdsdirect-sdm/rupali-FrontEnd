// Initialize the chart
const chartDom = document.getElementById('chart-container');
const myChart = echarts.init(chartDom);

// Initialize point selectors
const startSelect = document.getElementById('start-point');
const endSelect = document.getElementById('end-point');

// Populate selectors with points
for (const point in points) {
    const startOption = document.createElement('option');
    startOption.value = point;
    startOption.textContent = point;
    startSelect.appendChild(startOption);
    
    const endOption = document.createElement('option');
    endOption.value = point;
    endOption.textContent = point;
    endSelect.appendChild(endOption);
}

// Default selected values
startSelect.value = 'A';
endSelect.value = 'B';

// Register the SVG map
echarts.registerMap('floor-plan', { svg: svgData });

// Initialize with empty route
let option = {
    title: {
        text: 'Floor Plan Navigation',
        left: 'center',
        top: 10
    },
    tooltip: {
        trigger: 'item',
        formatter: '{b}'
    },
    geo: {
        map: 'floor-plan',
        roam: true,
        emphasis: {
            itemStyle: {
                color: undefined
            },
            label: {
                show: false
            }
        }
    },
    series: [
        {
            name: 'Points',
            type: 'scatter',
            coordinateSystem: 'geo',
            data: Object.keys(points).map(key => ({
                name: key,
                value: [...points[key], key]
            })),
            symbolSize: 15,
            itemStyle: {
                color: '#ff5722'
            },
            label: {
                show: true,
                formatter: '{@[2]}',
                position: 'top'
            }
        },
        {
            name: 'Route',
            type: 'lines',
            coordinateSystem: 'geo',
            polyline: true,
            lineStyle: {
                color: '#c46e54',
                width: 5,
                opacity: 1,
                type: 'dotted'
            },
            effect: {
                show: true,
                period: 8,
                color: '#a10000',
                constantSpeed: 80,
                trailLength: 0,
                symbolSize: [15, 8],
                symbol: 'arrow'
            },
            data: []
        }
    ]
};

// Initial render
myChart.setOption(option);

// Function to update the path
function updatePath(coords) {
    option.series[1].data = [{
        coords: coords
    }];
    myChart.setOption(option);
}

// Function to clear the path
function clearPath() {
    option.series[1].data = [];
    myChart.setOption(option);
}

// Event listeners
document.getElementById('show-path').addEventListener('click', function() {
    const start = startSelect.value;
    const end = endSelect.value;
    
    const path = findPath(start, end);
    updatePath(path);
});

document.getElementById('clear-path').addEventListener('click', clearPath);

// Preset route buttons
document.querySelectorAll('.preset-button').forEach(button => {
    button.addEventListener('click', function() {
        const routeKey = this.getAttribute('data-route');
        if (presetRoutes[routeKey]) {
            updatePath(presetRoutes[routeKey]);
            
            // Update selectors to match the route
            const [start, end] = routeKey.split('-');
            startSelect.value = start;
            endSelect.value = end;
        }
    });
});

// Resize handler
window.addEventListener('resize', function() {
    myChart.resize();
});