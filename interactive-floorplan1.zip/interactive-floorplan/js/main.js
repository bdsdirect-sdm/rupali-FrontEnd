document.addEventListener('DOMContentLoaded', function () {
  const floorData = {
    points: {
      // Main building points (vertices and key locations)
      'A': [55, 65],   // Top left corner
      'B': [268, 65],  // Top right corner 
      'C': [280, 370], // Right middle
      'D': [300, 570], // Bottom right
      'E': [50, 580],  // Bottom left
      'F': [50, 370],  // Left middle
      'G': [155, 370], // Middle point
      'H': [165, 280], // Study rooms area
      'I': [90, 400],  // Center of collaborative area
      'J': [90, 556],  // Entrance point
      'K': [367, 585], // Cafeteria point
      'L': [360, 370], // Right corridor point
      'M': [290, 400], // Right middle corridor
      'N': [150, 280], // Left study room
      'O': [250, 280], // Right study room
      'P': [165, 280],  // Study rooms corridor
      'Q': [65, 280],
      'R': [65, 255],
      'S': [250, 255],
    },

    // Completely revised graph connections that follow the physical layout
    // and avoid cutting through buildings
    graph: {
      'A': ['B', 'F', 'R'],   // Top left connects to top right, left middle, and point R
      'B': ['A', 'C', 'S'],   // Top right connects to top left, right middle, and point S
      'C': ['B', 'L', 'M'],   // Right middle connects appropriately
      'D': ['M', 'K', 'E'],   // Bottom right connects to right and bottom
      'E': ['D', 'F', 'J'],   // Bottom left connects to right, left, and entrance
      'F': ['A', 'E', 'G', 'Q'], // Left middle with all valid connections, including Q
      'G': ['F', 'H', 'I', 'M'],  // Middle connections
      'H': ['G', 'N', 'O', 'P'],  // Study rooms area
      'I': ['G', 'J', 'M'],       // Collaborative area - note no direct connection to K
      'J': ['E', 'I'],            // Entrance connections
      'K': ['L', 'D'],            // Cafeteria connects to right corridor and bottom right
      'L': ['C', 'K', 'M'],       // Right corridor connects properly
      'M': ['C', 'D', 'G', 'I'],  // Right middle corridor connections
      'N': [ 'H', 'P', 'O'],       // Left study room connections
      'O': ['H', 'P', 'S', 'N'],       // Right study room connections, now connected to S
      'P': ['N', 'O', 'H'],       // Study rooms corridor
      'Q': ['F', 'R'],            // Q connects to F and R
      'R': ['A', 'Q', 'S'],       // R connects to A, Q, and S
      'S': ['B', 'R', 'O']        // S connects to B, R, and O
    },

    // Points to display (including your new points)
    visiblePoints: ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S']
  };

  // SVG data for the floor plan
  const svgData = `
<svg width="600" height="900" xmlns="http://www.w3.org/2000/svg">
  <!-- Main floor areas -->
  <rect x="50" y="60" width="220" height="350" fill="#c8e6c9" stroke="#000" stroke-width="1"/>
  <rect x="50" y="380" width="300" height="200" fill="#bbdefb" stroke="#000" stroke-width="1"/>

  <!-- Rooms and features -->
  <rect x="70" y="80" width="180" height="180" fill="#a5d6a7" stroke="#000" stroke-width="1"/>
  <text x="160" y="170" text-anchor="middle" font-size="12">Research Collection</text>
  <rect x="70" y="280" width="80" height="100" fill="#a5d6a7" stroke="#000" stroke-width="1"/>
  <text x="110" y="330" text-anchor="middle" font-size="10">Study Room</text>
  <rect x="170" y="280" width="80" height="100" fill="#a5d6a7" stroke="#000" stroke-width="1"/>
  <text x="210" y="330" text-anchor="middle" font-size="10">Study Room</text>
  <rect x="100" y="400" width="200" height="160" fill="#90caf9" stroke="#000" stroke-width="1"/>
  <text x="200" y="480" text-anchor="middle" font-size="14">Collaborative Study Area</text>

  <!-- Stairs and Elevators -->
  <rect x="40" y="350" width="20" height="20" fill="#ffd54f" stroke="#000"/>
  <text x="50" y="365" text-anchor="middle" font-size="14">S</text>
  <rect x="370" y="350" width="20" height="20" fill="#ffc107" stroke="#000"/>
  <text x="380" y="365" text-anchor="middle" font-size="14">E</text>
  <rect x="370" y="600" width="20" height="20" fill="#ffc107" stroke="#000"/>
  <text x="380" y="615" text-anchor="middle" font-size="14">E</text>
  <rect x="40" y="600" width="20" height="20" fill="#ffd54f" stroke="#000"/>
  <text x="50" y="615" text-anchor="middle" font-size="14">S</text>
  
  <!-- Add corridor paths for visualization -->
  <path d="M50,370 L280,370" stroke="#ddd" stroke-width="1" stroke-dasharray="3,3" fill="none"/>
  <path d="M280,370 L280,550" stroke="#ddd" stroke-width="1" stroke-dasharray="3,3" fill="none"/>
  <path d="M50,370 L50,580" stroke="#ddd" stroke-width="1" stroke-dasharray="3,3" fill="none"/>
  <path d="M50,580 L300,550" stroke="#ddd" stroke-width="1" stroke-dasharray="3,3" fill="none"/>
</svg>
`;

  class FloorPathFinder {
    constructor(points, graph, visiblePoints) {
      this.points = points;
      this.graph = graph;
      this.visiblePoints = visiblePoints || Object.keys(points);
      this.pathResult = null;
    }

    // Calculate Euclidean distance between two points
    distance(point1, point2) {
      const dx = point1[0] - point2[0];
      const dy = point1[1] - point2[1];
      return Math.sqrt(dx * dx + dy * dy);
    }

    // Implementation of Dijkstra's algorithm for shortest path finding
    findPath(start, end) {
      // Handle case where start and end are the same
      if (start === end) {
        return { coordinates: [this.points[start]], nodeNames: [start] };
      }

      // Priority queue for Dijkstra's algorithm
      const openSet = [start];
      const closedSet = new Set();
      const cameFrom = {};
      const gScore = {};
      Object.keys(this.points).forEach(point => {
        gScore[point] = Infinity;
      });
      gScore[start] = 0;
      const fScore = {};
      fScore[start] = this.distance(this.points[start], this.points[end]);

      while (openSet.length > 0) {
        // Find vertex with lowest fScore in openSet
        let lowestIndex = 0;
        for (let i = 1; i < openSet.length; i++) {
          if (fScore[openSet[i]] < fScore[openSet[lowestIndex]]) {
            lowestIndex = i;
          }
        }

        const current = openSet[lowestIndex];

        // Check if we've reached the destination
        if (current === end) {
          // Reconstruct path
          const nodePath = [];
          let temp = current;
          nodePath.push(temp);

          while (cameFrom[temp]) {
            temp = cameFrom[temp];
            nodePath.unshift(temp);
          }

          this.pathResult = {
            coordinates: nodePath.map(node => this.points[node]),
            nodeNames: nodePath
          };
          return this.pathResult;
        }

        // Remove current from openSet and add to closedSet
        openSet.splice(lowestIndex, 1);
        closedSet.add(current);

        // Check if node exists in graph
        if (!this.graph[current]) {
          console.error(`No graph entry for node: ${current}`);
          continue;
        }

        // Check all neighbors
        for (const neighbor of this.graph[current]) {
          if (closedSet.has(neighbor)) continue;

          const tentativeGScore = gScore[current] + this.distance(this.points[current], this.points[neighbor]);

          if (!openSet.includes(neighbor)) {
            openSet.push(neighbor);
          } else if (tentativeGScore >= gScore[neighbor]) {
            continue;
          }

          // This path is the best until now. Record it!
          cameFrom[neighbor] = current;
          gScore[neighbor] = tentativeGScore;
          fScore[neighbor] = gScore[neighbor] + this.distance(this.points[neighbor], this.points[end]);
        }
      }

      console.error(`No path found from ${start} to ${end}`);
      this.pathResult = { coordinates: [this.points[start], this.points[end]], nodeNames: [start, end] };
      return this.pathResult;
    }

    // Get edges for visualization
    getGraphEdges() {
      const graphEdges = [];
      for (const [node, neighbors] of Object.entries(this.graph)) {
        for (const neighbor of neighbors) {
          // Only show edges for visible points
          if (this.visiblePoints.includes(node) && this.visiblePoints.includes(neighbor)) {
            graphEdges.push({
              coords: [this.points[node], this.points[neighbor]]
            });
          }
        }
      }
      return graphEdges;
    }

    // Get all edges for debugging (including hidden waypoints)
    getAllGraphEdges() {
      const graphEdges = [];
      for (const [node, neighbors] of Object.entries(this.graph)) {
        for (const neighbor of neighbors) {
          graphEdges.push({
            coords: [this.points[node], this.points[neighbor]]
          });
        }
      }
      return graphEdges;
    }

    // Get points data for visualization
    getPointsData(visibleOnly = true) {
      const pointsToShow = visibleOnly ? this.visiblePoints : Object.keys(this.points);
      return pointsToShow.map(key => ({
        name: key,
        value: [...this.points[key], key]
      }));
    }
  }

  // Initialize the path finder with floor data
  const pathFinder = new FloorPathFinder(floorData.points, floorData.graph, floorData.visiblePoints);
  const chartDom = document.getElementById('chart-container');
  const myChart = echarts.init(chartDom);
  const pathInfoDiv = document.getElementById('path-info');
  const startSelect = document.getElementById('start-point');
  const endSelect = document.getElementById('end-point');
  const showEdgesCheckbox = document.getElementById('show-edges');
  const showAllWaypointsCheckbox = document.getElementById('show-all-waypoints');

  // Clear existing options
  startSelect.innerHTML = '';
  endSelect.innerHTML = '';

  // Populate the dropdown menus with all available points
  floorData.visiblePoints.forEach(point => {
    const startOption = document.createElement('option');
    startOption.value = point;
    startOption.textContent = point;
    startSelect.appendChild(startOption);

    const endOption = document.createElement('option');
    endOption.value = point;
    endOption.textContent = point;
    endSelect.appendChild(endOption);
  });

  // Set default values
  startSelect.value = 'J'; // Entrance
  endSelect.value = 'K'; // Cafeteria

  // Register the SVG map
  echarts.registerMap('floor-plan', { svg: svgData });

  // Initial chart configuration
  // Find this section in your main.js file:
  // Initial chart configuration
  const option = {
    title: {
      text: 'Floor Plan Navigation',
      left: 'center',
      top: 10
    },
    tooltip: {
      trigger: 'item',
      formatter: '{b}'
    },
    geo: {
      map: 'floor-plan',
      roam: true,
      emphasis: {
        itemStyle: {
          color: undefined
        },
        label: {
          show: false
        }
      }
    },
    // REPLACE THE CURRENT SERIES ARRAY WITH THIS:
    series: [
      {
        name: 'Points',
        type: 'scatter',
        coordinateSystem: 'geo',
        data: pathFinder.getPointsData(true),
        symbolSize: 5,  // REDUCED from 12 to 6 for smaller points
        itemStyle: {
          color: '#f44336' // Red for all points
        },
        label: {
          show: true,
          formatter: '{@[2]}',
          position: 'right',
          fontSize: 10  // REDUCED from 12 to 10 for smaller labels
        }
      },
      {
        // Edges visualization
        name: 'Graph Edges',
        coordinateSystem: 'geo',
        type: 'lines',
        polyline: false,
        lineStyle: {
          color: '#aaa',
          width: 1,
          opacity: 0.5,
          type: 'dashed'
        },
        data: [],
        z: 1
      },
      {
        // Path visualization
        name: 'Route',
        type: 'lines',
        coordinateSystem: 'geo',
        polyline: true,
        lineStyle: {
          color: '#c46e54',
          width: 2,  // REDUCED from 5 to 2 for thinner lines
          opacity: 0.8,
          type: 'dashed',  // CHANGED from 'solid' to 'dashed'
          dashOffset: 5
        },
        effect: {
          show: true,
          period: 6,
          color: '#a10000',
          constantSpeed: 80,
          trailLength: 0.3,  // REDUCED from 0.5 to 0.3
          symbolSize: [6, 3],  // REDUCED from [10, 5] to [6, 3]
          symbol: 'arrow'
        },
        data: [],
        z: 2
      }
    ]
  };

  // Set initial options
  myChart.setOption(option);

  // Function to update the path visualization
  function updatePath(startPoint, endPoint) {
    const pathResult = pathFinder.findPath(startPoint, endPoint);
    option.series[2].data = [{ coords: pathResult.coordinates }];
    myChart.setOption(option);

    // Display path information
    const pathString = pathResult.nodeNames.join(' → ');
    const distance = calculatePathDistance(pathResult.coordinates);
    pathInfoDiv.innerHTML = `<strong>Path:</strong> ${pathString}<br><strong>Distance:</strong> ${distance.toFixed(2)} units`;

    return pathResult;
  }

  // Calculate total path distance
  function calculatePathDistance(coordinates) {
    let totalDistance = 0;
    for (let i = 0; i < coordinates.length - 1; i++) {
      const point1 = coordinates[i];
      const point2 = coordinates[i + 1];
      const dx = point1[0] - point2[0];
      const dy = point1[1] - point2[1];
      totalDistance += Math.sqrt(dx * dx + dy * dy);
    }
    return totalDistance;
  }

  // Function to toggle graph edges visibility
  function toggleEdges(show) {
    if (show) {
      option.series[1].data = pathFinder.getGraphEdges();
    } else {
      option.series[1].data = [];
    }
    myChart.setOption(option);
  }

  // Function to clear the path
  function clearPath() {
    option.series[2].data = [];
    myChart.setOption(option);
    pathInfoDiv.innerHTML = '';
  }

  // Event listeners
  document.getElementById('show-path').addEventListener('click', function () {
    const start = startSelect.value;
    const end = endSelect.value;
    updatePath(start, end);
  });

  document.getElementById('clear-path').addEventListener('click', clearPath);

  if (showEdgesCheckbox) {
    showEdgesCheckbox.addEventListener('change', function () {
      toggleEdges(this.checked);
    });
  }

  // Handle window resize to make chart responsive
  window.addEventListener('resize', function () {
    myChart.resize();
  });

  // Initial path calculation
  updatePath('J', 'K'); // From entrance to cafeteria
});