class FloorPathFinder {
    constructor(points, graph, visiblePoints) {
      this.points = points;
      this.graph = graph;
      this.visiblePoints = visiblePoints || Object.keys(points);
      this.pathResult = null;
    }
  
    distance(point1, point2) {
      const dx = point1[0] - point2[0];
      const dy = point1[1] - point2[1];
      return Math.sqrt(dx * dx + dy * dy);
    }
  
    findPath(start, end) {
      if (start === end) {
        return {
          coordinates: [this.points[start]],
          nodeNames: [start]
        };
      }
  
      const openSet = [start];
      const closedSet = new Set();
      const cameFrom = {};
      const gScore = {};
      gScore[start] = 0;
      const fScore = {};
      fScore[start] = this.distance(this.points[start], this.points[end]);
      
      while (openSet.length > 0) {
        let lowestIndex = 0;
        for (let i = 1; i < openSet.length; i++) {
          if (fScore[openSet[i]] < fScore[openSet[lowestIndex]]) {
            lowestIndex = i;
          }
        }
        
        const current = openSet[lowestIndex];
  
        if (current === end) {
          const nodePath = [];
          let temp = current;
          nodePath.push(temp);
          
          while (cameFrom[temp]) {
            temp = cameFrom[temp];
            nodePath.unshift(temp);
          }
          
          this.pathResult = {
            coordinates: nodePath.map(node => this.points[node]),
            nodeNames: nodePath
          };
          return this.pathResult;
        }
        
        openSet.splice(lowestIndex, 1);
        closedSet.add(current);
        
        if (!this.graph[current]) {
          console.error(`No graph entry for node: ${current}`);
          continue;
        }
        
        for (const neighbor of this.graph[current]) {
          if (closedSet.has(neighbor)) {
            continue;
          }
          
          const tentativeGScore = gScore[current] + this.distance(this.points[current], this.points[neighbor]);
          if (!openSet.includes(neighbor)) {
            openSet.push(neighbor);
          } else if (tentativeGScore >= gScore[neighbor]) {
            continue;
          }
          
          cameFrom[neighbor] = current;
          gScore[neighbor] = tentativeGScore;
          fScore[neighbor] = gScore[neighbor] + this.distance(this.points[neighbor], this.points[end]);
        }
      }
      
      console.error(`No path found from ${start} to ${end}`);
      this.pathResult = {
        coordinates: [this.points[start], this.points[end]], 
        nodeNames: [start, end]
      };
      return this.pathResult;
    }
  
    getGraphEdges() {
      const graphEdges = [];
      for (const [node, neighbors] of Object.entries(this.graph)) {
        for (const neighbor of neighbors) {
          graphEdges.push({
            coords: [this.points[node], this.points[neighbor]]
          });
        }
      }
      return graphEdges;
    }
  
    getPointsData(visibleOnly = true) {
      const pointsToShow = visibleOnly ? this.visiblePoints : Object.keys(this.points);
      return pointsToShow.map(key => ({
        name: key,
        value: [...this.points[key], key]
      }));
    }
  
    getHiddenPointsData() {
      return Object.keys(this.points)
        .filter(key => !this.visiblePoints.includes(key))
        .map(key => ({
          name: key,
          value: [...this.points[key], key]
        }));
    }
  }