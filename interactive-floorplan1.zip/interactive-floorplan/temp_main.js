document.addEventListener('DOMContentLoaded', function() {
    // Floor plan data
    const floorData = {
      points: {
        // Original points
        'A': [110.6189462165178, 456.64349563895087],
        'B': [123.9272226116071, 389.9520693708147],
        'C': [61.58708083147317, 72.8954315876116],
        'D': [258.29514854771196, 72.8954315876116],
        'E': [280.5277985253906, 390.2406672084263],
        'F': [492.8750778390066, 560.9895157073103],
        'G': [294.9255269587053, 827.9639780566406],
        'H': [282.79803391043527, 868.2476088113839],
        'Entrance': [110.6189462165178, 456.64349563895087],
        'Classroom': [260.75457021484374, 336.8559607533482],
        'Study Room': [221.36468155133926, 758.7870354617745],
        'Cafeteria': [366.8489324762834, 560.9895157073103],
        
        // Corridor network - horizontal corridors (expanded with more points)
        'H1': [60, 50], 'H2': [160, 50], 'H3': [260, 50],
        'H4': [60, 150], 'H5': [160, 150], 'H6': [260, 150],
        'H7': [60, 270], 'H8': [160, 270], 'H9': [260, 270],
        'H10': [60, 370], 'H11': [160, 370], 'H12': [260, 370],
        'H13': [60, 480], 'H14': [160, 480], 'H15': [260, 480], 'H16': [350, 480], 'H17': [420, 480], 'H18': [500, 480],
        'H19': [60, 580], 'H20': [160, 580], 'H21': [260, 580], 'H22': [350, 580], 'H23': [420, 580], 'H24': [500, 580],
        'H25': [60, 680], 'H26': [160, 680], 'H27': [260, 680], 'H28': [350, 680], 'H29': [420, 680], 'H30': [500, 680],
        'H31': [60, 780], 'H32': [160, 780], 'H33': [260, 780], 'H34': [350, 780], 'H35': [420, 780], 'H36': [500, 780],
        'H37': [60, 880], 'H38': [160, 880], 'H39': [260, 880], 'H40': [350, 880], 'H41': [420, 880], 'H42': [500, 880],
        
        // Corridor network - vertical corridors (expanded with more points)
        'V1': [60, 50], 'V2': [60, 150], 'V3': [60, 270], 'V4': [60, 370], 'V5': [60, 480], 
        'V6': [60, 580], 'V7': [60, 680], 'V8': [60, 780], 'V9': [60, 880],
        
        'V10': [160, 50], 'V11': [160, 150], 'V12': [160, 270], 'V13': [160, 370], 'V14': [160, 480], 
        'V15': [160, 580], 'V16': [160, 680], 'V17': [160, 780], 'V18': [160, 880],
        
        'V19': [260, 50], 'V20': [260, 150], 'V21': [260, 270], 'V22': [260, 370], 'V23': [260, 480], 
        'V24': [260, 580], 'V25': [260, 680], 'V26': [260, 780], 'V27': [260, 880],
        
        'V28': [350, 480], 'V29': [350, 580], 'V30': [350, 680], 'V31': [350, 780], 'V32': [350, 880],
        
        'V33': [420, 480], 'V34': [420, 580], 'V35': [420, 680], 'V36': [420, 780], 'V37': [420, 880],
        
        'V38': [500, 480], 'V39': [500, 580], 'V40': [500, 680], 'V41': [500, 780], 'V42': [500, 880],
        
        // Corner points for rooms (perimeter)
        'C1': [50, 60], 'C2': [270, 60], 'C3': [50, 380], 'C4': [350, 380],
        'C5': [50, 600], 'C6': [550, 600], 'C7': [50, 900], 'C8': [550, 900],
        
        // Points around room boundaries
        'R1': [70, 80], 'R2': [250, 80], 'R3': [70, 260], 'R4': [250, 260],
        'R5': [70, 280], 'R6': [150, 280], 'R7': [170, 280], 'R8': [250, 280],
        'R9': [70, 380], 'R10': [150, 380], 'R11': [170, 380], 'R12': [250, 380],
        'R13': [100, 400], 'R14': [300, 400], 'R15': [100, 560], 'R16': [300, 560],
        'R17': [420, 400], 'R18': [520, 400], 'R19': [420, 480], 'R20': [520, 480],
        'R21': [420, 500], 'R22': [520, 500], 'R23': [420, 560], 'R24': [520, 560],
        'R25': [320, 620], 'R26': [480, 620], 'R27': [320, 720], 'R28': [480, 720],
        'R29': [320, 740], 'R30': [480, 740], 'R31': [320, 820], 'R32': [480, 820]
      },
      graph: {
        // Connect original points to corridor network
        'A': ['H13', 'V5'],
        'B': ['H11', 'V13'],
        'C': ['H1', 'V1'],
        'D': ['H3', 'V19'],
        'E': ['H16', 'V28'],
        'F': ['H24', 'V39'],
        'G': ['H34', 'V31'],
        'H': ['H40', 'V32'],
        'Entrance': ['A'],
        'Classroom': ['H9', 'H12'],
        'Study Room': ['H32', 'H33'],
        'Cafeteria': ['H22', 'H28'],
        
        // Horizontal corridor connections
        'H1': ['V1', 'H2'], 'H2': ['H1', 'H3', 'V10'], 'H3': ['H2', 'V19', 'D'],
        'H4': ['V2', 'H5'], 'H5': ['H4', 'H6', 'V11'], 'H6': ['H5', 'V20'],
        'H7': ['V3', 'H8'], 'H8': ['H7', 'H9', 'V12'], 'H9': ['H8', 'V21', 'Classroom'],
        'H10': ['V4', 'H11'], 'H11': ['H10', 'H12', 'V13', 'B'], 'H12': ['H11', 'V22', 'Classroom'],
        'H13': ['V5', 'H14', 'A'], 'H14': ['H13', 'H15', 'V14'], 'H15': ['H14', 'H16', 'V23'],
        'H16': ['H15', 'H17', 'V28', 'E'], 'H17': ['H16', 'H18', 'V33'], 'H18': ['H17', 'V38'],
        'H19': ['V6', 'H20'], 'H20': ['H19', 'H21', 'V15'], 'H21': ['H20', 'H22', 'V24'],
        'H22': ['H21', 'H23', 'V29', 'Cafeteria'], 'H23': ['H22', 'H24', 'V34'], 'H24': ['H23', 'V39', 'F'],
        'H25': ['V7', 'H26'], 'H26': ['H25', 'H27', 'V16'], 'H27': ['H26', 'H28', 'V25'],
        'H28': ['H27', 'H29', 'V30', 'Cafeteria'], 'H29': ['H28', 'H30', 'V35'], 'H30': ['H29', 'V40'],
        'H31': ['V8', 'H32'], 'H32': ['H31', 'H33', 'V17', 'Study Room'], 'H33': ['H32', 'H34', 'V26', 'Study Room'],
        'H34': ['H33', 'H35', 'V31', 'G'], 'H35': ['H34', 'H36', 'V36'], 'H36': ['H35', 'V41'],
        'H37': ['V9', 'H38'], 'H38': ['H37', 'H39', 'V18'], 'H39': ['H38', 'H40', 'V27'],
        'H40': ['H39', 'H41', 'V32', 'H'], 'H41': ['H40', 'H42', 'V37'], 'H42': ['H41', 'V42'],
        
        // Vertical corridor connections
        'V1': ['H1', 'V2', 'C'], 'V2': ['V1', 'H4', 'V3'], 'V3': ['V2', 'H7', 'V4'],
        'V4': ['V3', 'H10', 'V5'], 'V5': ['V4', 'H13', 'V6', 'A'],
        'V6': ['V5', 'H19', 'V7'], 'V7': ['V6', 'H25', 'V8'], 'V8': ['V7', 'H31', 'V9'],
        'V9': ['V8', 'H37'],
        
        'V10': ['H2', 'V11'], 'V11': ['V10', 'H5', 'V12'], 'V12': ['V11', 'H8', 'V13'],
        'V13': ['V12', 'H11', 'V14', 'B'], 'V14': ['V13', 'H14', 'V15'],
        'V15': ['V14', 'H20', 'V16'], 'V16': ['V15', 'H26', 'V17'], 'V17': ['V16', 'H32', 'V18', 'Study Room'],
        'V18': ['V17', 'H38'],
        
        'V19': ['H3', 'V20', 'D'], 'V20': ['V19', 'H6', 'V21'], 'V21': ['V20', 'H9', 'V22', 'Classroom'],
        'V22': ['V21', 'H12', 'V23', 'Classroom'], 'V23': ['V22', 'H15', 'V24'],
        'V24': ['V23', 'H21', 'V25'], 'V25': ['V24', 'H27', 'V26'], 'V26': ['V25', 'H33', 'V27', 'Study Room'],
        'V27': ['V26', 'H39'],
        
        'V28': ['H16', 'V29', 'E'], 'V29': ['V28', 'H22', 'V30', 'Cafeteria'],
        'V30': ['V29', 'H28', 'V31', 'Cafeteria'], 'V31': ['V30', 'H34', 'V32', 'G'],
        'V32': ['V31', 'H40', 'H'],
        
        'V33': ['H17', 'V34'], 'V34': ['V33', 'H23', 'V35'],
        'V35': ['V34', 'H29', 'V36'], 'V36': ['V35', 'H35', 'V37'],
        'V37': ['V36', 'H41'],
        
        'V38': ['H18', 'V39'], 'V39': ['V38', 'H24', 'V40', 'F'],
        'V40': ['V39', 'H30', 'V41'], 'V41': ['V40', 'H36', 'V42'],
        'V42': ['V41', 'H42'],
        
        // Connect room boundary points
        'C1': ['R1', 'V1'], 'C2': ['R2', 'V19'], 'C3': ['R9', 'V4'], 'C4': ['R14', 'V28'],
        'C5': ['R15', 'V6'], 'C6': ['R24', 'V39'], 'C7': ['V9'], 'C8': ['V42'],
        
        'R1': ['C1', 'R2', 'R3'], 'R2': ['R1', 'C2', 'R4'], 'R3': ['R1', 'R4', 'R5'],
        'R4': ['R2', 'R3', 'R8'], 'R5': ['R3', 'R6', 'R9'], 'R6': ['R5', 'R7', 'R10'],
        'R7': ['R6', 'R8', 'R11'], 'R8': ['R4', 'R7', 'R12'], 'R9': ['R5', 'C3', 'R10', 'R13'],
        'R10': ['R6', 'R9', 'R11'], 'R11': ['R7', 'R10', 'R12'], 'R12': ['R8', 'R11', 'R14'],
        'R13': ['R9', 'R14', 'R15'], 'R14': ['R12', 'R13', 'C4', 'R16'], 'R15': ['R13', 'C5', 'R16'],
        'R16': ['R14', 'R15', 'R25'], 'R17': ['V33', 'R18', 'R19'], 'R18': ['R17', 'V38', 'R20'],
        'R19': ['R17', 'R20', 'R21'], 'R20': ['R18', 'R19', 'R22'], 'R21': ['R19', 'R22', 'R23'],
        'R22': ['R20', 'R21', 'R24'], 'R23': ['R21', 'R24'], 'R24': ['R22', 'R23', 'C6'],
        'R25': ['R16', 'R26', 'R27'], 'R26': ['R25', 'R28'], 'R27': ['R25', 'R28', 'R29'],
        'R28': ['R26', 'R27', 'R30'], 'R29': ['R27', 'R30', 'R31'], 'R30': ['R28', 'R29', 'R32'],
        'R31': ['R29', 'R32', 'G'], 'R32': ['R30', 'R31']
      },
      visiblePoints: ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'Entrance', 'Classroom', 'Study Room', 'Cafeteria']
    };
  
    // SVG Floor Plan
    const svgData = `
      <svg width="600" height="900" xmlns="http://www.w3.org/2000/svg">
          <!-- Main floor areas -->
          <rect x="50" y="60" width="220" height="350" fill="#c8e6c9" stroke="#000" stroke-width="1"/>
          <rect x="50" y="380" width="300" height="200" fill="#bbdefb" stroke="#000" stroke-width="1"/>
          <rect x="400" y="380" width="150" height="200" fill="#ffcdd2" stroke="#000" stroke-width="1"/>
          <rect x="300" y="600" width="200" height="250" fill="#e1bee7" stroke="#000" stroke-width="1"/>
  
          <!-- Rooms and features -->
          <rect x="70" y="80" width="180" height="180" fill="#a5d6a7" stroke="#000" stroke-width="1"/>
          <text x="160" y="170" text-anchor="middle" font-size="12">Research Collection</text>
          <rect x="70" y="280" width="80" height="100" fill="#a5d6a7" stroke="#000" stroke-width="1"/>
          <text x="110" y="330" text-anchor="middle" font-size="10">Study Room</text>
          <rect x="170" y="280" width="80" height="100" fill="#a5d6a7" stroke="#000" stroke-width="1"/>
          <text x="210" y="330" text-anchor="middle" font-size="10">Study Room</text>
          <rect x="100" y="400" width="200" height="160" fill="#90caf9" stroke="#000" stroke-width="1"/>
          <text x="200" y="480" text-anchor="middle" font-size="14">Collaborative Study Area</text>
          <rect x="420" y="400" width="100" height="80" fill="#ef9a9a" stroke="#000" stroke-width="1"/>
          <text x="470" y="440" text-anchor="middle" font-size="10">Office</text>
          <rect x="420" y="500" width="100" height="60" fill="#ef9a9a" stroke="#000" stroke-width="1"/>
          <text x="470" y="530" text-anchor="middle" font-size="10">Office</text>
          <rect x="320" y="620" width="160" height="100" fill="#d1c4e9" stroke="#000" stroke-width="1"/>
          <text x="400" y="670" text-anchor="middle" font-size="12">Computer Lab</text>
          <rect x="320" y="740" width="160" height="80" fill="#d1c4e9" stroke="#000" stroke-width="1"/>
          <text x="400" y="780" text-anchor="middle" font-size="12">Meeting Room</text>
  
          <!-- Corridors (visualized) -->
          <path d="M50,30 L550,30 L550,930 L50,930 L50,30" 
                fill="none" stroke="#aaaaaa" stroke-width="2" stroke-dasharray="5,5"/>
          <path d="M60,50 L500,50 M60,150 L260,150 M60,270 L260,270 M60,370 L260,370 
                   M60,480 L500,480 M60,580 L500,580 M60,680 L500,680 M60,780 L500,780 M60,880 L500,880" 
                fill="none" stroke="#aaaaaa" stroke-width="2"/>
          <path d="M60,50 L60,880 M160,50 L160,880 M260,50 L260,880 
                   M350,480 L350,880 M420,480 L420,880 M500,480 L500,880" 
                fill="none" stroke="#aaaaaa" stroke-width="2"/>
  
          <!-- Key Points -->
          <circle cx="110" cy="456" r="8" fill="#ff0000" stroke="#000"/>
          <text x="110" y="440" text-anchor="middle" font-size="12">A</text>
          <circle cx="124" cy="390" r="8" fill="#ff0000" stroke="#000"/>
          <text x="124" y="374" text-anchor="middle" font-size="12">B</text>
          <circle cx="62" cy="73" r="8" fill="#ff0000" stroke="#000"/>
          <text x="62" y="57" text-anchor="middle" font-size="12">C</text>
          <circle cx="258" cy="73" r="8" fill="#ff0000" stroke="#000"/>
          <text x="258" y="57" text-anchor="middle" font-size="12">D</text>
          <circle cx="280" cy="410" r="8" fill="#ff0000" stroke="#000"/>
          <text x="280" y="394" text-anchor="middle" font-size="12">E</text>
          <circle cx="493" cy="561" r="8" fill="#ff0000" stroke="#000"/>
          <text x="493" y="545" text-anchor="middle" font-size="12">F</text>
          <circle cx="295" cy="828" r="8" fill="#ff0000" stroke="#000"/>
          <text x="295" y="812" text-anchor="middle" font-size="12">G</text>
          <circle cx="283" cy="868" r="8" fill="#ff0000" stroke="#000"/>
          <text x="283" y="852" text-anchor="middle" font-size="12">H</text>
  
          <!-- Stairs and Elevators -->
          <rect x="40" y="350" width="20" height="20" fill="#ffd54f" stroke="#000"/>
          <text x="50" y="365" text-anchor="middle" font-size="14">S</text>
          <rect x="370" y="350" width="20" height="20" fill="#ffc107" stroke="#000"/>
          <text x="380" y="365" text-anchor="middle" font-size="14">E</text>
          <rect x="370" y="600" width="20" height="20" fill="#ffc107" stroke="#000"/>
          <text x="380" y="615" text-anchor="middle" font-size="14">E</text>
          <rect x="40" y="600" width="20" height="20" fill="#ffd54f" stroke="#000"/>
          <text x="50" y="615" text-anchor="middle" font-size="14">S</text>
      </svg>
    `;
  
    // Initialize path finder
    const pathFinder = new FloorPathFinder(
      floorData.points, 
      floorData.graph, 
      floorData.visiblePoints
    );
  
    // Initialize chart
    const chartDom = document.getElementById('chart-container');
    const myChart = echarts.init(chartDom);
    const pathInfoDiv = document.getElementById('path-info');
  
    // Populate dropdowns
    const startSelect = document.getElementById('start-point');
    const endSelect = document.getElementById('end-point');
    
    floorData.visiblePoints.forEach(point => {
      const startOption = document.createElement('option');
      startOption.value = point;
      startOption.textContent = point;
      startSelect.appendChild(startOption);
  
      const endOption = document.createElement('option');
      endOption.value = point;
      endOption.textContent = point;
      endSelect.appendChild(endOption);
    });
  
    startSelect.value = 'A';
    endSelect.value = 'B';
  
    // Register map and set initial options
    echarts.registerMap('floor-plan', { svg: svgData });
    
    const option = {
      title: {
        text: 'Floor Plan Navigation',
        left: 'center',
        top: 10
      },
      tooltip: {
        trigger: 'item',
        formatter: '{b}'
      },
      geo: {
        map: 'floor-plan',
        roam: true,
        emphasis: {
          itemStyle: {
            color: undefined
          },
          label: {
            show: false
          }
        }
      },
      series: [
        {
          name: 'Points',
          type: 'scatter',
          coordinateSystem: 'geo',
          data: pathFinder.getPointsData(true),
          symbolSize: 15,
          itemStyle: {
            color: '#ff5722'
          },
          label: {
            show: true,
            formatter: '{@[2]}',
            position: 'top'
          }
        },
        {
          name: 'Hidden Points',
          type: 'scatter',
          coordinateSystem: 'geo',
          data: pathFinder.getHiddenPointsData(),
          symbolSize: 8,
          itemStyle: {
            color: '#888888',
            opacity: 0
          },
          label: {
            show: false
          }
        },
        {
          name: 'Graph Edges',
          type: 'lines',
          coordinateSystem: 'geo',
          polyline: true,
          lineStyle: {
            color: '#aaaaaa',
            width: 2,
            opacity: 0
          },
          data: []
        },
        {
          name: 'Route',
          type: 'lines',
          coordinateSystem: 'geo',
          polyline: true,
          lineStyle: {
            color: '#c46e54',
            width: 5,
            opacity: 1,
            type: 'dotted'
          },
          effect: {
            show: true,
            period: 8,
            color: '#a10000',
            constantSpeed: 80,
            trailLength: 0,
            symbolSize: [15, 8],
            symbol: 'arrow'
          },
          data: []
        }
      ]
    };
    
    myChart.setOption(option);
  
    // UI interaction functions
    function updatePath(startPoint, endPoint) {
      const pathResult = pathFinder.findPath(startPoint, endPoint);
      
      option.series[3].data = [{ coords: pathResult.coordinates }];
      myChart.setOption(option);
  
      const pathString = pathResult.nodeNames.join(' → ');
      pathInfoDiv.innerHTML = `<strong>Path:</strong> ${pathString}`;
      
      return pathResult;
    }
  
    function clearPath() {
      option.series[3].data = [];
      myChart.setOption(option);
      pathInfoDiv.innerHTML = '';
    }
  
    function toggleGraphVisibility(show) {
      option.series[1].itemStyle.opacity = show ? 0.7 : 0;
      option.series[1].label.show = show;
      
      if (show && option.series[2].data.length === 0) {
        option.series[2].data = pathFinder.getGraphEdges();
      }
  
      option.series[2].lineStyle.opacity = show ? 0.7 : 0;
      
      myChart.setOption(option);
    }
  
    // Preset routes
    const presetRoutes = {
      'A-B': () => updatePath('A', 'B'),
      'C-E': () => updatePath('C', 'E'),
      'B-D': () => updatePath('B', 'D'),
      'D-F': () => updatePath('D', 'F'),
      'A-F': () => updatePath('A', 'F'),
      'Entrance-Cafeteria': () => updatePath('Entrance', 'Cafeteria'),
      'Study Room-Classroom': () => updatePath('Study Room', 'Classroom'),
      'G-H': () => updatePath('G', 'H')
    };
  
    // Event listeners
    document.getElementById('show-path').addEventListener('click', function() {
      const start = startSelect.value;
      const end = endSelect.value;
      updatePath(start, end);
    });
  
    document.getElementById('clear-path').addEventListener('click', clearPath);
  
    document.getElementById('show-graph').addEventListener('change', function() {
      toggleGraphVisibility(this.checked);
    });
  
    document.querySelectorAll('.preset-button').forEach(button => {
      button.addEventListener('click', function() {
        const routeKey = this.getAttribute('data-route');
        if (presetRoutes[routeKey]) {
          presetRoutes[routeKey]();
          const [start, end] = routeKey.split('-');
          startSelect.value = start;
          endSelect.value = end;
        }
      });
    });
  
    window.addEventListener('resize', function() {
      myChart.resize();
    });
  });